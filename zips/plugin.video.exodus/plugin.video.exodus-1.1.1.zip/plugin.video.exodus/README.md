======================
Exodus
======================

# exodus-library
Kodi Exodus w/ Favourite Library Feature

- I take no credit for Exodus, and thank Lambda for their hard work.
- Added the favourite library feature back into version 1.1.1, so please copy your favourites.db file from Genesis over.
- Will hope to be added to keep this updated, assuming I can proceed in doing such.

Thanks,
Arcane47

License
-------
This software is released under the [GPL 3.0 license] [1].
[1]: http://www.gnu.org/licenses/gpl-3.0.html
